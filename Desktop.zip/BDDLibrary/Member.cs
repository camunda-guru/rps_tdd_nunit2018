﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDDLibrary
{
    public class Member
    {
        private string name;

        public string Name
        {
            get { return name; }
            set {
                if (value.Length > 0)
                    name = value;
                else
                    name = null;
            }
        }
        
        public string CheckValid()
        {
            if (this.name != null)
                return "valid";
            else
                return "invalid";
        }


    }
}
