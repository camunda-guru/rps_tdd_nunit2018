﻿using BDDLibrary;
using NUnit.Framework;
using System;
using TechTalk.SpecFlow;

namespace BDDDemo
{
    [Binding]
    public class LoginSteps
    {


        [Given(@"the user has entered '(.*)' in the Name field")]
        public void GivenTheUserHasEnteredInTheNameField(string name)
        {


            ScenarioContext.Current.Add("Name", name);
        }
        [Given(@"the user has not entered Name filed value")]
        public void GivenTheUserHasNotEnteredNameFiledValue()
        {
            ScenarioContext.Current.Add("Name", "");
        }

        [When(@"I Validate the field")]
        public void WhenIValidateTheField()
        {
            var name = (string)ScenarioContext.Current["Name"];
            var member = new Member();
            member.Name = name;

            var addResult = member.CheckValid();

            ScenarioContext.Current.Add("AddResult", addResult);

        }

        [Then(@"I see a message saying Name is '(.*)'")]
        public void ThenISeeAMessageSayingNameIs(string expectedResult)
        {
            var addResult = (string)ScenarioContext.Current["AddResult"];
            Assert.AreEqual(expectedResult, addResult);

        }


        
    }
}
